#!/bin/sh
mvn clean integration-test -P fortify-sca
